enum OpportunityCategory { lodging, viandas, gastronomy, places }

enum OpportunityTag {
  group,
  budget,
  direct,
  classic,
  thermal,
  practical,
  paseo,
  highlighted,
}

class ContactAction {
  const ContactAction({
    required this.label,
    required this.url,
    required this.icon,
  });

  final String label;
  final String url;
  final String icon;
}

class OpportunityItem {
  const OpportunityItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.category,
    required this.tags,
    required this.highlights,
    required this.actions,
    this.note,
  });

  final String id;
  final String title;
  final String subtitle;
  final String description;
  final OpportunityCategory category;
  final List<OpportunityTag> tags;
  final List<String> highlights;
  final List<ContactAction> actions;
  final String? note;
}

class HomeHighlight {
  const HomeHighlight({
    required this.title,
    required this.value,
    required this.caption,
  });

  final String title;
  final String value;
  final String caption;
}
