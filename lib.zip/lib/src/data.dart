import 'models.dart';

const homeHighlights = <HomeHighlight>[
  HomeHighlight(
    title: 'Alojamiento',
    value: '8',
    caption: 'Opciones prioritarias para consultar primero',
  ),
  HomeHighlight(
    title: 'Viandas',
    value: '3',
    caption: 'Canales prácticos para resolver comida',
  ),
  HomeHighlight(
    title: 'Paseos',
    value: '5',
    caption: 'Lugares simples de sumar en una estadía corta',
  ),
];

const topRecommendations = <String>[
  'Pedir primero un bloqueo grupal a Centro Plaza Hotel.',
  'Medir ahorro real con Casa Di Aqua y opciones de alquiler turístico.',
  'Resolver comida base con Tus Viandas o Yantar.',
  'Usar Costanera y Parque San Carlos como paseos simples y rendidores.',
];

const cannedMessage =
    'Hola, consulto disponibilidad y tarifa para agosto para un grupo. '
    'Buscamos una opción práctica y económica. ¿Podrían pasar capacidad, '
    'precio y qué incluye?';

const opportunities = <OpportunityItem>[
  OpportunityItem(
    id: 'centro-plaza',
    title: 'Centro Plaza Hotel',
    subtitle: 'La consulta más fuerte para concentrar el grupo',
    description:
        'Es la mejor opción cuando conviene resolver muchas plazas en un solo edificio céntrico.',
    category: OpportunityCategory.lodging,
    tags: [
      OpportunityTag.group,
      OpportunityTag.direct,
      OpportunityTag.highlighted,
    ],
    highlights: [
      '27 habitaciones y 62 plazas informadas por el sitio oficial',
      'Desayuno incluido',
      'Buena base para una sola sede',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454339886',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:info@centroplazahotel.com.ar',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Web',
        url: 'https://centroplazahotel.com.ar/',
        icon: 'web',
      ),
    ],
    note: 'Conviene pedir tarifa por bloque y condiciones de desayuno.',
  ),
  OpportunityItem(
    id: 'casa-di-aqua',
    title: 'Casa Di Aqua Apart Hotel',
    subtitle: 'Flexible para repartir gente y bajar costo por unidad',
    description:
        'Rinde cuando el grupo puede dividirse en departamentos más chicos sin perder orden operativo.',
    category: OpportunityCategory.lodging,
    tags: [OpportunityTag.group, OpportunityTag.direct, OpportunityTag.budget],
    highlights: [
      'Unidades para 3, 4, 5 y 6 personas',
      'Perfil apto para contingentes',
      'Canal directo con consulta de tarifas',
    ],
    actions: [
      ContactAction(
        label: 'Mail',
        url: 'mailto:info@casadiaqua.com.ar',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Web',
        url: 'https://casadiaqua.com.ar/',
        icon: 'web',
      ),
      ContactAction(
        label: 'Tarifas',
        url: 'https://casadiaqua.com.ar/tarifas/',
        icon: 'price',
      ),
    ],
  ),
  OpportunityItem(
    id: 'el-bicho-negro',
    title: 'El Bicho Negro Hostel',
    subtitle: 'Hostel de perfil más agresivo en costo',
    description:
        'Sirve cuando el objetivo principal es reducir gasto y aceptar formato compartido.',
    category: OpportunityCategory.lodging,
    tags: [OpportunityTag.budget, OpportunityTag.direct, OpportunityTag.group],
    highlights: [
      'Canal de WhatsApp directo',
      'Buena línea para precio',
      'Hostel y no hotel clásico',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5491165983888',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Guía',
        url:
            'https://www.concordia.gob.ar/turismo/donde-dormir/hostels/el-bicho-negro-hostel',
        icon: 'web',
      ),
      ContactAction(
        label: 'Sitio',
        url: 'https://www.elbichonegrohostel.com/',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'alojamiento-avenida',
    title: 'Alojamiento Avenida',
    subtitle: 'Casa de alquiler turística accesible',
    description:
        'Buena línea para salir de hotelería clásica y abrir una negociación más económica.',
    category: OpportunityCategory.lodging,
    tags: [OpportunityTag.budget, OpportunityTag.direct],
    highlights: [
      'Canal directo por WhatsApp',
      'Figura en la guía oficial',
      'Útil como opción de costo contenido',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454745409',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:maraaldecoa87@gmail.com',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Guía',
        url:
            'https://www.concordia.gob.ar/turismo/donde-dormir/casas-de-alquiler-tur%C3%ADstico/alojamiento-avenida',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'hospedaje-vz',
    title: 'Hospedaje V.Z.',
    subtitle: 'Alternativa económica y directa',
    description:
        'Sirve para ampliar capacidad con un formato más simple y probablemente más barato.',
    category: OpportunityCategory.lodging,
    tags: [OpportunityTag.budget, OpportunityTag.direct],
    highlights: [
      'WhatsApp directo',
      'Mail visible',
      'Ubicado dentro de las guías oficiales',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454129852',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:hospedajeyquinchovz@gmail.com',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Guía',
        url:
            'https://www.concordia.gob.ar/turismo/donde-dormir/casas-de-alquiler-tur%C3%ADstico/hospedaje-vz-hospedaje-y-quincho',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'termal-del-lago',
    title: 'Termal del Lago',
    subtitle: 'Más completo que económico',
    description:
        'Sirve cuando se prioriza comodidad y entorno termal por encima del costo más bajo.',
    category: OpportunityCategory.lodging,
    tags: [OpportunityTag.thermal, OpportunityTag.direct],
    highlights: [
      'WhatsApp y mail directos',
      'Perfil más completo',
      'Mejor para una estadía más cuidada',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454198179',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:consultas@termaldellago.net',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Web',
        url: 'https://termaldellago.net/',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'casa-nebel',
    title: 'Casa Nebel',
    subtitle: 'Casa turística para sumar plazas con canal directo',
    description:
        'Sirve para ampliar capacidad fuera del formato hotelero tradicional y pelear un costo más flexible.',
    category: OpportunityCategory.lodging,
    tags: [OpportunityTag.budget, OpportunityTag.direct, OpportunityTag.group],
    highlights: [
      'WhatsApp directo',
      'Figura en la guía turística local',
      'Útil para repartir grupo y bajar costo promedio',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454927363',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Guía',
        url:
            'https://www.concordia.gob.ar/turismo/donde-dormir/casas-de-alquiler-tur%C3%ADstico/casa-nebel',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'hathor',
    title: 'Hathor Concordia',
    subtitle: 'Plan B de escala hotelera más completa',
    description:
        'No es la línea más barata, pero sirve como respaldo cuando se necesita una operación más cerrada y formal.',
    category: OpportunityCategory.lodging,
    tags: [
      OpportunityTag.group,
      OpportunityTag.direct,
      OpportunityTag.highlighted,
    ],
    highlights: [
      'WhatsApp y mail directos',
      'Hotel con perfil más corporativo',
      'Útil como respaldo si falla la primera línea económica',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454325710',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:reservasconcordia@hathorhotels.com.ar',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Web',
        url: 'https://www.hathorconcordia.com.ar/contacto/',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'tus-viandas',
    title: 'Tus Viandas Concordia',
    subtitle: 'La opción más directa para resolver viandas',
    description:
        'Es la referencia más alineada con comida operativa, simple y accionable.',
    category: OpportunityCategory.viandas,
    tags: [
      OpportunityTag.practical,
      OpportunityTag.direct,
      OpportunityTag.highlighted,
    ],
    highlights: [
      'Perfil específico de viandas',
      'WhatsApp y mail visibles',
      'Muy útil para resolver base alimentaria',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493455287506',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:tusviandasconcordia@gmail.com',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Ficha',
        url: 'https://www.concordia.gob.ar/node/11393',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'yantar-centro',
    title: 'Yantar Rotisería',
    subtitle: 'Comida rendidora y operativa',
    description:
        'Muy buena alternativa para resolver una comida completa sin complejidad.',
    category: OpportunityCategory.viandas,
    tags: [OpportunityTag.practical, OpportunityTag.direct],
    highlights: [
      'WhatsApp directo',
      'Correo visible',
      'Sirve bien para una logística corta',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454210414',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:yantarrotiseria@gmail.com',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Ficha',
        url: 'https://www.concordia.gob.ar/node/267',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'yantar-costa',
    title: 'Yantar de la Costa',
    subtitle: 'Comida práctica con salida combinada',
    description:
        'Puede funcionar para vincular comida y paseo en la zona de Costanera.',
    category: OpportunityCategory.viandas,
    tags: [OpportunityTag.practical, OpportunityTag.paseo],
    highlights: [
      'Buena para una salida simple',
      'Canal directo por WhatsApp',
      'Ubicación favorable para paseo',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454112829',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Mail',
        url: 'mailto:yantarrotiseria@gmail.com',
        icon: 'mail',
      ),
      ContactAction(
        label: 'Ficha',
        url: 'https://www.concordia.gob.ar/node/271',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'bar-ideal',
    title: 'Bar Ideal',
    subtitle: 'Clásico de Concordia',
    description:
        'Sirve cuando se quiere una comida más identitaria sin mucha producción extra.',
    category: OpportunityCategory.gastronomy,
    tags: [OpportunityTag.classic, OpportunityTag.highlighted],
    highlights: [
      'Nombre muy reconocible',
      'Buena referencia urbana',
      'Más experiencia local que vianda',
    ],
    actions: [
      ContactAction(
        label: 'Ficha',
        url: 'https://ahgconcordia.com.ar/asociado/bar-ideal/',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'parrilla-el-gordo',
    title: 'Parrilla El Gordo',
    subtitle: 'Parrilla accesible y utilizable',
    description:
        'Rinde para una comida más fuerte con perfil simple y accionable.',
    category: OpportunityCategory.gastronomy,
    tags: [OpportunityTag.classic, OpportunityTag.direct],
    highlights: [
      'WhatsApp directo',
      'Buena para una comida destacada sin lujo',
      'Apta para combinar con plan económico',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454226311',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Guía',
        url: 'https://www.concordia.gob.ar/node/4394',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'richmond',
    title: 'Richmond Street Food Bar',
    subtitle: 'Opción urbana dentro de Mercado Plaza',
    description:
        'Sirve para una salida más liviana y moderna dentro del circuito gastronómico.',
    category: OpportunityCategory.gastronomy,
    tags: [OpportunityTag.direct, OpportunityTag.paseo],
    highlights: [
      'WhatsApp directo',
      'Formato más casual',
      'Bien ubicado para salida breve',
    ],
    actions: [
      ContactAction(
        label: 'WhatsApp',
        url: 'https://wa.me/5493454146822',
        icon: 'whatsapp',
      ),
      ContactAction(
        label: 'Ficha',
        url: 'https://ahgconcordia.com.ar/asociado/richmond-street-food-bar/',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'parque-san-carlos',
    title: 'Parque San Carlos',
    subtitle: 'Paseo emblemático',
    description:
        'Uno de los puntos más reconocibles de la ciudad, con mezcla de naturaleza e historia.',
    category: OpportunityCategory.places,
    tags: [OpportunityTag.paseo, OpportunityTag.highlighted],
    highlights: [
      'Muy representativo de Concordia',
      'Sirve para una salida corta',
      'Combina bien con Costanera o gastronomía',
    ],
    actions: [
      ContactAction(
        label: 'Ver sitio',
        url:
            'https://www.concordia.gob.ar/turismo/atractivos/parque-san-carlos',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'costanera',
    title: 'Costanera',
    subtitle: 'Paseo simple y combinable',
    description:
        'Es probablemente el paseo más fácil de sumar sin complicar la logística.',
    category: OpportunityCategory.places,
    tags: [OpportunityTag.paseo],
    highlights: [
      'Accesible',
      'Combina con comida o merienda',
      'Ideal para rato corto',
    ],
    actions: [
      ContactAction(
        label: 'Ver sitio',
        url: 'https://www.concordia.gob.ar/turismo/atractivos/costanera',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'termas',
    title: 'Termas',
    subtitle: 'Salida fuerte para invierno',
    description:
        'Uno de los grandes atractivos de Concordia y un argumento claro para agosto.',
    category: OpportunityCategory.places,
    tags: [OpportunityTag.paseo, OpportunityTag.thermal],
    highlights: [
      'Muy alineado con agosto',
      'Salida más fuerte que un paseo urbano',
      'Buen valor turístico',
    ],
    actions: [
      ContactAction(
        label: 'Ver sitio',
        url: 'https://www.concordia.gob.ar/turismo/atractivos/termas',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'concorpass',
    title: 'ConcorPass',
    subtitle: 'Herramienta oficial para ordenar beneficios y recorrido',
    description:
        'Sirve para revisar beneficios y apoyarse en la oferta turística oficial antes de cerrar el plan de paseo.',
    category: OpportunityCategory.places,
    tags: [OpportunityTag.paseo, OpportunityTag.practical],
    highlights: [
      'Canal oficial de turismo',
      'Útil para complementar la estadía',
      'Sirve para ordenar opciones desde móvil',
    ],
    actions: [
      ContactAction(
        label: 'Ver sitio',
        url: 'https://www.concordia.gob.ar/turismo/concorpass',
        icon: 'web',
      ),
    ],
  ),
  OpportunityItem(
    id: 'portal-turismo',
    title: 'Portal de Turismo',
    subtitle: 'Base oficial para ampliar agenda y servicios',
    description:
        'Sirve como referencia rápida para ampliar hospedajes, gastronomía y destacados sin salir del entorno oficial.',
    category: OpportunityCategory.places,
    tags: [OpportunityTag.paseo, OpportunityTag.practical],
    highlights: [
      'Fuente oficial consolidada',
      'Amplía recorridos y servicios',
      'Buena base para seguir relevando',
    ],
    actions: [
      ContactAction(
        label: 'Ver sitio',
        url: 'https://www.concordia.gob.ar/turismo',
        icon: 'web',
      ),
    ],
  ),
];
